# Code2Inv Benchmark

Benchmark for linear invariant generation from the Code2Inv paper:
https://github.com/PL-ML/code2inv/tree/master/benchmarks

In order to download and convert the benchmark, you can run the following:

```sh
sh benchmarks/code2inv/install.sh
```