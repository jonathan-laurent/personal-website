# COLT

*Colt*, which stands for _Coq Learning Tools_ is a set of tools for automated
premise selection in Coq. In particular, it provides a tactic _hint_
that ranks the available lemmas by respect to their relevance in proving a given fact
and outputs the best ones to the user. This tactic relies on machine learning techniques 
that capture useful connections between the symbols that appear in a statement and 
which lemmas are used in its proof, in a similar fashion to the premise selector of Sledgehammer.


## Setup instructions:

Requirements:

+ Coq 8.5 with sources and `coq-dpdgraph` installed
+ Ocaml compiler (> 4.02)
+ Python (> 3.5.1) with numpy and scikit-learn

In order to build the Coq plugin, just type `make`. 

The `python3` command should be bound to a python interpreter which is compatible 
with the requirements above. If not, set the variable `PYTHON` in `colt` manually. 


## Basic usage with CoRN or mathcomp

We give the following instructions for _CoRN_ but the same hold for _mathcomp_: 
just replace `CoRN` by `mathcomp` everywhere.

First, you need to preprocess the CoRN library. In order to do this, write the path 
to the CoRN sources directory in the file `/examples/CoRN/config/path`. Then, run:

`./scripts/build.sh ./examples/CoRN`

After this, you need to fit a premise selector from the sources of CoRN by typing:

`./colt learn examples/CoRN/features -o ./models/nb`

Finally, add the following lines in your working Coq file:

+ `Colt Set LoadPath "..."` where `...` is replaced by the path of colt on your disk
+ `Colt Set Model "nb"`
+ `Require Import colt.plugin.plugin`

Now, you can use the tactic `hint n` just after the `Proof` keyword of a statement
will need to update the paths in it before you use it though.
in order to get _n_ suggestions. An example can be found in the file `examples/Test.v`. You


## FAQ

### How to use an other library than CoRN or mathcomp ?

Just clone the `examples/template` directory and modify its `config` subdirectory.
If you don't understand the role of a file, look at the script that uses it in the
`scripts` folder.

### How to generate cover curves ?

Use `./colt eval example/CoRN/features` if you followed the CoRN basic usage 
instructions. Otherwise, consult `./colt eval --help`

### Where can I get more help ?
Use `./colt --help` and `./colt [subcommand] --help` or email to `jonathan-laurent@live.fr`

