#!/bin/bash

coq_makefile -f Make -o Makefile
make
