#!/bin/bash

for f in ./examples/* ; do
    if [ -d $f ] ; then
        echo "Cleaning $f"
        ./scripts/clean.sh $f
    fi
done
