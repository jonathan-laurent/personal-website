#!/bin/bash

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'


readonly PROGDIR=$(pwd)/$(dirname $0)

readonly FDIR=$1

cd $FDIR


echo "Looking for modules."

$PROGDIR/list-modules.sh > modules

echo "Generating dependencies graph."

cat modules | $PROGDIR/deps.sh > Deps.v

cat Deps.v | coqtop &> /dev/null # Creates graph.dpd

echo "Listing lemmas."

cat graph.dpd | $PROGDIR/props.sed > props-full

# Small subset
cat props-full | sed -n '1,$ p' > props

cat props | $PROGDIR/extract-features.sh modules > Features.v

echo "Extracting features."

cat Features.v | coqtop &> /dev/null

echo "Removing blacklisted features."

$PROGDIR/blacklist.sh features

echo -e $GREEN'Done.'$NC

echo ""

$PROGDIR/stats.sh
