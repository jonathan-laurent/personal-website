#!/bin/bash

LIBPATH=$(cat config/path)

LOAD_PATHS="$LIBPATH $(dirname $LIBPATH)"

for p in $LOAD_PATHS ; do echo 'Add LoadPath "'$p'".' ; done

LOADPATH=$(dirname $(cat config/path))


echo ""

MODULES=$(cat)

echo "$MODULES" | sed 's/.*/Require &./'

echo ""
echo "Require dpdgraph.dpdgraph."

echo 'Print FileDependGraph '$(echo -n $MODULES | tr "\n" " ")'.'
