#!/bin/bash

LEMMAS=$(find features -iname "*.features")
nlemmas=$(echo "$LEMMAS$" | wc -l)

echo "Number of lemmas: $nlemmas."

nfeats=$(cat $LEMMAS | wc -l)

echo "Number of features: $nfeats."

ndeps=$(cat $LEMMAS | sed -n '/dep:/ p' | wc -l)

nuniqdeps=$(cat $LEMMAS | sed -n '/dep:/ p' | sort | uniq | wc -l)

echo "Number of dependencies: $ndeps ($nuniqdeps unique)."
