#!/bin/bash
# Argument: list of modules 
# Input: list of lemmas

LIBPATH=$(cat config/path)

PLUGIN_DIR=$(dirname $(dirname $0))/plugin

LOAD_PATHS="$PLUGIN_DIR $PLUGIN_DIR/../.. $LIBPATH $(dirname $LIBPATH)"

DIR='./features'

for p in $LOAD_PATHS ; do echo 'Add LoadPath "'$p'".' ; done

echo ""

echo "Require colt.plugin.plugin."

echo ""

cat $1 | sed 's/.*/Require &./'

echo ""

while read lemma
do
    file=$DIR/$(echo -n $lemma | tr "." "/" | sed 's/.*/&\.features/')
    mkdir -p $(dirname $file)
    echo 'Write Features '$lemma' in "'$file'".'
done


# Usage: cat props | extract-features.sh modules | coqtop > /dev/null
