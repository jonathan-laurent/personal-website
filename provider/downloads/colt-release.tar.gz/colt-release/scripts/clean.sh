#!/bin/bash

readonly FDIR=$1

cd $FDIR
rm -rf features
rm -f *.v *.dpd modules props props-full
