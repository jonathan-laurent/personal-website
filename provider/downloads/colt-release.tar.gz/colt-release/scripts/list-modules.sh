#!/bin/sh
# Args: none
# Reads: [config/libname] [config/path] [config/folders]
# Returns: a list of Coq modules

BASE=$(cat config/path)

LIBNAME=$(cat config/libname)

DIRS=$(cat config/folders | sed "s:.*:$BASE/&:")

FILES=$(find $DIRS -iname "*.v" -not -name "Opaque_*" -not -name "Transparent_*")

OPTIONS="-R $BASE $LIBNAME"

SORTED=$(coqdep -sort $OPTIONS $FILES)

echo $SORTED | tr [:blank:] "\n" | sed 's:/:\.:g' | sed "s:.*\($LIBNAME\..*\)\.vo:\1:" | config/modules-blacklist.sed

#echo $SORTED | tr [:blank:] "\n" | sed 's:/:\.:g' | sed "s:\($LIBNAME\..*\)\.vo:\1:"

#echo "Total: $(echo $SORTED | wc -w) modules."
