#!/bin/bash

FOLDER=$1
FILES=$(find $FOLDER -iname "*.features")

for f in $FILES
do
    cat $f | config/blacklist.sed > tmp
    mv tmp $f
done

rm -f tmp
