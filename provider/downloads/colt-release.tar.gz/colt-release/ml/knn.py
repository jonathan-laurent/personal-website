import numpy as np

from classifier import *

from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfTransformer


class KNN(Base):

    def __init__(self, train_from=None, from_file="", lam=6, k=50, numfeats_weight=0.1):
        self.numfeats_weight = numfeats_weight
        self.lam = lam
        self.k = k
        Base.__init__(self, train_from, from_file)
        

    def stack_feats(self, X1, X2):
        n1 = np.shape(X1)[1]
        n2 = np.shape(X2)[1]
        return np.hstack((X1, (n1 / (n2 + 1)) * self.numfeats_weight * X2))


    def fit(self, T):
        self.T = T
        
        Xsp = []
        X2sp = []
        Ysp = []
        D = []

        for k, fs in T.feats.items():
            ds = T.deps[k]
            Xsp.append(feats_list_to_dict(fs))
            X2sp.append(T.numfeats[k])
            Ysp.append(feats_list_to_dict(ds))
            D.append(k)

        self.xvect = DictVectorizer()
        self.x2vect = DictVectorizer()
        self.yvect = DictVectorizer()
        self.tfidf = TfidfTransformer(norm=None)

        X = self.tfidf.fit_transform(self.xvect.fit_transform(Xsp)).toarray()
        X2 = self.x2vect.fit_transform(X2sp).toarray()

        self.X = self.stack_feats(X, X2)
        self.Y = self.yvect.fit_transform(Ysp).toarray()



    def best_lemmas(self, fs, numfs={}, n=-1):
        
        # Line vector
        Xq = self.xvect.transform([feats_list_to_dict(fs)])
        Xq = self.tfidf.transform(Xq).toarray()
        X2q = self.x2vect.transform([numfs]).toarray()

        Xq = self.stack_feats(Xq, X2q)
        
        # dims: [nsamples]
        dists = np.linalg.norm(Xq[0,:] - self.X, ord=1, axis=1)
        
        ranking = np.argsort(dists)
        sorted_dists = np.sort(dists)
        
        w = np.exp(- self.lam * sorted_dists / sorted_dists[self.k])

        dep_ids = np.argsort(np.sum(self.Y[ranking, :] * w[:,None], axis=0) / np.sum(w))[::-1]

        suggs = np.array(self.yvect.get_feature_names())[dep_ids][:n]  

        return suggs



    def known_deps(self):
        return self.yvect.get_feature_names()
