import numpy as np

from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import LatentDirichletAllocation

import classifier
from classifier import *

debug_mode = False

def dbg(s):
    if debug_mode:
        print(s)

def remove_minus_inf(X, eps=1e-8):
    X2 = np.array(X)
    X2[X2 <= eps] = eps
    return X2

def proba_normalized_1d(v):
    return v / np.sum(v)

def proba_normalized_2d(X):
    s = np.sum(X, axis=1)
    return X / s[:,None]

def from_log_proba(logP):
    m = np.max(logP)
    P = np.exp(logP - m)
    return P / np.sum(P)


def add_dep_prefix(l):
    return ["dep:" + s for s in l]

def remove_dep_prefix(l):
    return [s.split(":")[1] for s in l]


class LDA(classifier.Base):

    def __init__(self, train_from=None, from_file="", n_topics=40, alpha=50, eta=50):
        self.n_topics = n_topics
        self.alpha=alpha
        self.eta=eta
        Base.__init__(self, train_from, from_file)


    def get_state(self):
        st = []
        st.append(self.n_topics)
        st.append(self.vectorizer)
        st.append(self.tfidf)
        st.append(self.clf)
        st.append(self.beta_feat)
        st.append(self.beta_dep)
        st.append(self.fnames)
        st.append(self.known_deps_)
        return st


    def set_state(self, st):
        self.n_topics     = st[0]
        self.vectorizer   = st[1]
        self.tfidf        = st[2]
        self.clf          = st[3]
        self.beta_feat    = st[4]
        self.beta_dep     = st[5]
        self.fnames       = st[6]
        self.known_deps_  = st[7]


    def fit(self, T):

        Xsp = []
        D   = []

        for k, fs in T.feats.items():
            fsds = fs + add_dep_prefix(T.deps[k])
            Xsp.append(feats_list_to_dict(fsds))
            D.append(k)


        self.vectorizer = DictVectorizer()
        self.tfidf = TfidfTransformer(norm=None)

        X = self.tfidf.fit_transform(self.vectorizer.fit_transform(Xsp))

        self.clf = LatentDirichletAllocation(n_topics=self.n_topics,
                                             doc_topic_prior = self.alpha / self.n_topics,
                                             topic_word_prior = self.eta / self.n_topics,
                                             verbose=0)

        self.clf.fit(X)

        # Separate standard features from dependencies

        self.fnames = np.array(self.vectorizer.get_feature_names())

        dep_ids  = []
        feat_ids = []

        for i in range(len(self.fnames)):
            prefix = self.fnames[i].split(":")[0]
            if prefix == "dep":
                dep_ids.append(i)
            else:
                feat_ids.append(i)

        self.known_deps_ = remove_dep_prefix(self.fnames[dep_ids])


        # Learn normalized betas

        beta_raw = self.clf.components_

        beta_dep = np.array(beta_raw)
        beta_dep[:,feat_ids] = 0
        self.beta_dep = proba_normalized_2d(beta_dep)

        beta_feat = np.array(beta_raw)
        beta_feat[:,dep_ids] = 0
        self.beta_feat = proba_normalized_2d(beta_feat)

        self.clf.components_ = self.beta_feat


    def print_topics(self, k=10):

        beta = self.clf.components_

        for t in range(self.n_topics):
            ranking = np.argsort(beta[t,:])[::-1][:k]
            best = self.fnames[ranking]
            probs = beta[t, ranking]

            print("TOPIC {}:".format(t))

            for f, p in zip(best, probs):
                print ("{} [{}]".format(f, p))

            print("\n")


    def topics_distr(self, fs):

        Xq = self.vectorizer.transform([feats_list_to_dict(fs)])
        Xq = self.tfidf.transform(Xq).toarray()[0,:]

        return proba_normalized_1d(self.clf.transform(np.array([Xq]))[0,:])


    def alt_topics_distr():

        Xq = self.vectorizer.transform([feats_list_to_dict(fs)])
        Xq = self.tfidf.transform(Xq).toarray()[0,:]

        tdistr_log = np.nan_to_num(np.nan_to_num(np.log(self.beta_feat)).dot(Xq))
        tdistr = from_log_proba(tdistr_log)

        return tdistr


    def best_lemmas(self, fs, numfs={}, n=-1):

        tdistr = self.topics_distr(fs)

        pdeps = tdistr.dot(self.beta_dep)

        ranking = np.argsort(pdeps)[::-1][:n]

        best = remove_dep_prefix(self.fnames[ranking])

        return best


    def known_deps(self):
        return self.known_deps_



    def enhance_dataset(self, T):

        for k in T.names:

            tdistr = self.topics_distr(T.feats[k])

            D = {}
            for i in range(len(tdistr)):
                D["top:{}".format(i)] = tdistr[i]

            T.numfeats[k] = D


