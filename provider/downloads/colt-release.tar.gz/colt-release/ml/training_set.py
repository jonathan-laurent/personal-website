# Import the training set.

import os
import sys
import random

from collections import namedtuple

TS = namedtuple("TS", ["names", "deps", "feats", "catdeps", "numfeats"])


def explore(dir, prefix, Tdeps, Tfeats, Tnumfeats):

    def cons(s, t):
        return s + "." + t if s != "" else t

    def add_feat(lemma, ft):
        ty, ct = ft.split(":")
        if ty == "dep":
            Tdeps[lemma].append(ct)
        else:
            Tfeats[lemma].append(ft)

    for f in os.listdir(dir):
        fp = dir + "/" + f
        if os.path.isdir(fp):
            explore(fp, cons(prefix, f), Tdeps, Tfeats, Tnumfeats)
        else:
            lemma = cons(prefix, f.split(".")[0])
            Tdeps[lemma]  = []
            Tfeats[lemma] = []
            Tnumfeats[lemma] = {}
            with open(fp) as file:
                fts = file.read().splitlines()
                for ft in fts:
                    add_feat(lemma, ft)


def load(dir):

    Tdeps = {}
    Tfeats = {}
    Tnumfeats = {}
    explore(dir, "", Tdeps, Tfeats, Tnumfeats)
    Tnames = list(Tdeps.keys())
    Tcatdeps = list(deps_freq(Tdeps).keys())
    T = TS(Tnames, Tdeps, Tfeats, Tcatdeps, Tnumfeats)
    return T


def deps_freq(Tdeps):

    deps_freq = {}

    for l, fs in Tdeps.items():
        for f in fs:
            deps_freq[f] = deps_freq.get(f, 0) + 1

    return deps_freq


def deps_usage(T):

    sorted_deps = sorted([(f, c) for f, c in deps_freq(T.deps).items()], key=(lambda x : x[1]))
    sorted_deps = list(reversed(sorted_deps))

    return sorted_deps


def filter_deps(T, n=-1):
    """ Keep only the [n] most frequent dependencies.
    """

    sorted_deps = deps_usage(T)

    relevant_deps = [f for f, c in sorted_deps[:n]]

    relevant_deps_set = set(relevant_deps)

    for k in T.names:
        T.deps[k] = list(filter(lambda d : d in relevant_deps_set, T.deps[k]))

    T.catdeps = relevant_deps



def split(T, ratio=0.1):
    names = T.names[:]
    random.shuffle(names)

    sep = int(ratio * len(names))
    names_test = names[:sep]
    names_train = names[sep:]

    deps_test = {}
    deps_train = {}
    feats_test = {}
    feats_train = {}
    numfeats_train = {}
    numfeats_test = {}

    for k in names_test:
        deps_test[k]     = T.deps[k]
        feats_test[k]    = T.feats[k]
        numfeats_test[k] = T.numfeats[k]

    for k in names_train:
        deps_train[k]     = T.deps[k]
        feats_train[k]    = T.feats[k]
        numfeats_train[k] = T.numfeats[k]


    T_test  = TS(names_test, deps_test, feats_test, T.catdeps, numfeats_test)
    T_train = TS(names_train, deps_train, feats_train, T.catdeps, numfeats_train)

    return T_train, T_test


def size(T):
    return len(T.names)


import matplotlib.pyplot as plt

def print_stats(T):

    sorted_deps = deps_usage(T)


    for f, c in sorted_deps[:200]:
        print("{}: {}".format(f, c))


    h=5
    plt.figure("Training set stats", (3*h, h))
    
    plt.subplot(121)
    plt.title("Histogram of dependency frequencies")
    
    plt.hist([c for f, c in sorted_deps if c <= 100], bins=50)
    plt.gca().set_yscale("log")
    
    plt.subplot(122)
    plt.title("Number of deps with at least a given frequency")
    xx = range(1, 100)
    yy = [len([c for f, c in sorted_deps if c >= x]) for x in xx]
    plt.plot(xx, yy)
    plt.show()

