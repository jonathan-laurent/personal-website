import numpy as np

from classifier import *

from sklearn.naive_bayes import BernoulliNB, MultinomialNB
from sklearn.feature_extraction import DictVectorizer
from sklearn.feature_extraction.text import TfidfTransformer


class NaiveBayes(Base):
    
    def __init__(self, train_from=None, from_file="", berNB=False, \
                 tfidf_enabled=True, numfeats_weight=0):

        self.berNB = berNB
        self.tfidf_enabled = tfidf_enabled
        self.numfeats_weight = numfeats_weight
        Base.__init__(self, train_from, from_file)

    def get_state(self):
        return (self.berNB, self.tfidf_enabled, self.numfeats_weight, \
                self.clf, self.xvect, self.x2vect, \
                self.tfidf, self.catdeps)

    def set_state(self, st):
        self.berNB            = st[0]
        self.tfidf_enabled    = st[1]
        self.numfeats_weight  = st[2]
        self.clf              = st[3]
        self.xvect            = st[4]
        self.x2vect           = st[5]
        self.tfidf            = st[6]
        self.catdeps          = st[7]
        

    def stack_feats(self, X1, X2):
        w = self.numfeats_weight
        if w == 0:
            return X1
        else:
            return np.hstack((X1.toarray(), w * X2.toarray()))


    def fit(self, T):
        
        Xsp  = []
        X2sp = []    # Additional numerical features
        Ysp  = []
        D    = []

        for k, fs in T.feats.items():
            ds = T.deps[k]
            fdict = feats_list_to_dict(fs)
            numfeats = T.numfeats[k]
            for d in ds:
                Xsp.append(fdict)
                X2sp.append(numfeats)
                Ysp.append(d)
                D.append(k)

        self.xvect = DictVectorizer()
        self.x2vect = DictVectorizer()
        self.tfidf = TfidfTransformer(norm=None)

        X = self.xvect.fit_transform(Xsp)

        if self.tfidf_enabled:
            X = self.tfidf.fit_transform(X)

        X2 = self.x2vect.fit_transform(X2sp)
        X = self.stack_feats(X, X2)

        Y = Ysp

        if self.berNB:
            self.clf = BernoulliNB(alpha=1)
        else:
            self.clf = MultinomialNB(alpha=1)

        self.clf.fit(X, Y)

        self.catdeps = T.catdeps



    def best_lemmas(self, fs, numfs={}, n=-1):

        Xq = self.xvect.transform([feats_list_to_dict(fs)])
                
        if self.tfidf_enabled:
            Xq = self.tfidf.transform(Xq)
            
        X2q = self.x2vect.transform([numfs])
        Xq  = self.stack_feats(Xq, X2q)

        scores = self.clf.predict_log_proba(Xq)[0,:]
        sorted_deps = self.clf.classes_[np.argsort(scores)[::-1]][:n]
        return sorted_deps


    def known_deps(self):
        return self.clf.classes_
