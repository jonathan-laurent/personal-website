from numpy import *

import numpy as np

import training_set
import dumb
import evaluate

from naive_bayes import NaiveBayes
from knn import KNN
from lda import LDA
from combination import Merge


## Parameters

DEFAULT_MODEL_FILE = "models/model"
DEFAULT_FEATS_DIR  = "/home/jonathan/Stage/CoRN/features"
DEFAULT_SUGGESTED  = 100
DEFAULT_NTOPICS    = 40
DEFAULT_PERTOPIC   = 20
BER_NB             = False


## Recent experiments

def dev(args):
    T = training_set.load(args.features)
    T_train, T_test = training_set.split(T, ratio=0.1)

    CLDA = LDA(train_from=T_train)
    CLDA.enhance_dataset(T_train)
    CLDA.enhance_dataset(T_test)

    C_KNN = KNN(train_from=T_train, numfeats_weight=0)

    ests=[]
    #ests=[(KNN(train_from=T_train, numfeats_weight=w), "w = {}".format(w)) for w in [0, 1]]
    
    """
    C_KNN_LDA = Merge(KNN(train_from=T_train, numfeats_weight=0), \
              KNN(train_from=T_train, numfeats_weight=1000), \
              r=0.1)
    """

    C_KNN_NB = Merge(KNN(train_from=T_train, numfeats_weight=1), \
                     NaiveBayes(train_from=T_train), \
                     r = 0.2)
                     

    ests.append((C_KNN, "k-NN"))
    ests.append((C_KNN_NB , "k-NN + NB + LDA"))
    ests.append((KNN(train_from=T_train, numfeats_weight=1e4), "LDA"))
    ests.append((dumb.MostFrequent(T_train), "Most frequent"))

    evaluate.compare_estimators(ests, T_test, (1, 100))



def topics(args):

    T = training_set.load(args.features)
    C = LDA(train_from=T, n_topics = args.ntopics)
    C.print_topics(k = args.pertopic)
    

def lda(args):

    TRAIN = True
    model_file = 'lda.model'

    T = training_set.load(args.features)
    T_train, T_test = training_set.split(T, ratio=0.1)


    if TRAIN:
        CLDA = LDA(train_from=T_train)
        CLDA.save(model_file)
        #CLDA.print_topics(k=10)

    CLDA = LDA(from_file=model_file)
    # CLDA.print_topics(k=100)

    #CKNN = KNN(train_from=T_train)
    
    #CNB = NaiveBayes(train_from=T_train)

    #C = Merge(CNB, CKNN, r=0.7)

    #ests = [(C, "NB + k-NN"), (CNB, "Naive Bayes"), (CKNN, "k-NN")]

    #ests.append((KNN(train_from=T_train), "k-NN"))
    ests = [(CLDA, "LDA")]
    ests.append((dumb.MostFrequent(T_train), "Most Frequent"))

    evaluate.compare_estimators(ests, T_test, (1, 100))


"""
for k in range(10, 100, 10):
C = KNN(train_from=T_train, k=k, lam=2)
cover = evaluate.cover(C, T_test, n=100)
print("k={}  :  {}".format(k, cover))
"""


def eval(args):

     if args.nb_only:
         eval_naive_bayes(args)
     else:
        eval_full(args)


def eval_naive_bayes(args):

    T = training_set.load(args.features)
    T_train, T_test = training_set.split(T, ratio=0.1)

    ests = [(NaiveBayes(train_from=T_train), "Naive Bayes"), \
            (dumb.MostFrequent(T_train), "Most frequent")]

    evaluate.compare_estimators(ests, T_test, (1, 100))


def eval_full(args):

    T = training_set.load(args.features)
    T_train, T_test = training_set.split(T, ratio=0.1)

    print("Testing on {} samples.".format(training_set.size(T_test)))


    print("Extracting LDA topics.")
 
    CLDA = LDA(train_from=T_train)
    CLDA.enhance_dataset(T_train)
    CLDA.enhance_dataset(T_test)

    print("Evaluating: k-NN.")

    CKNN0   = KNN(train_from=T_train, numfeats_weight=0)
    CKNNLDA = KNN(train_from=T_train, numfeats_weight=1e4)

    print("Evaluating: Naive Bayes.")

    CNB     = NaiveBayes(train_from=T_train)

    if args.full:
        print("Evaluating: k-NN + NB")
        
        CNBKNN  = Merge(KNN(train_from=T_train, numfeats_weight=0), \
                        NaiveBayes(train_from=T_train), \
                        r = 0.2)

    print("Evaluating: k-NN + NB + LDA.")

    CBEST   = Merge(KNN(train_from=T_train, numfeats_weight=1), \
                    NaiveBayes(train_from=T_train), \
                    r = 0.2)

    CMFREQ  = dumb.MostFrequent(T_train)

    I  = (1, 100)
    
    ests  = [(CBEST, "k-NN + NB + LDA")]

    if args.full:
        ests += [(CNBKNN, "k-NN + NB")]
        
    ests += [(CKNN0, "k-NN"), (CNB, "NB (Naive Bayes)"), (CKNNLDA, "LDA")]
    ests += [(CMFREQ, "Most frequent")]

    evaluate.compare_estimators(ests, T_test, I)
    


## Get statistics about the features in use

def stats(args):
    T = training_set.load(args.features)
    training_set.print_stats(T)



## Learn a model

def learn(args):
    T = training_set.load(args.features)
    C = NaiveBayes(berNB=BER_NB, tfidf_enabled=False)
    C.fit(T)
    C.save(args.output)


## Suggest some lemmas: called by the Colt Coq plugin.

def suggest(args):

    classifier_file = args.model
    C = NaiveBayes(from_file=classifier_file)

    for l in C.best_lemmas(args.features.split(), n=args.n):
        print(l)



## Command line parser

import argparse

description='Machine learning tools for Coq.'

parser = argparse.ArgumentParser(prog='colt', description=description)

subparsers = parser.add_subparsers(dest='cmd')

parser_learn = subparsers.add_parser('learn', \
                                     help="fit a model against a training set")
parser_learn.set_defaults(hook=learn)
parser_learn.add_argument('features', help="training dataset")
parser_learn.add_argument('-o', '--output', \
                          default=DEFAULT_MODEL_FILE, \
                          help="Output file. By default:{}".format(DEFAULT_MODEL_FILE))

parser_eval = subparsers.add_parser('eval', \
                                    help='compare the different learning algorithms on a dataset')
parser_eval.set_defaults(hook=eval)
parser_eval.add_argument('features', help="dataset to use")
parser_eval.add_argument('--nb-only', help='evaluate only the naive bayes algorithm', action='store_true')
parser_eval.add_argument('--full', help='evaluate more algorithms but takes longer',  action='store_true')

parser_stats   = subparsers.add_parser('stats', \
                                       help='show some statistics about the features of a dataset')
parser_stats.set_defaults(hook=stats)
parser_stats.add_argument('features', help='dataset to analyze')

parser_suggest = subparsers.add_parser('suggest', \
                                       help='suggest some lemmas based on the features of the current goal and an existing model')
parser_suggest.set_defaults(hook=suggest)
parser_suggest.add_argument('features', help='goal features')
parser_suggest.add_argument('-m', '--model', default=DEFAULT_MODEL_FILE, 
                            help='model to use (default: {})'.format(DEFAULT_MODEL_FILE))
parser_suggest.add_argument('-n', type=int, default=DEFAULT_SUGGESTED, \
                            help='number of lemmas to propose (default: {})'.format(DEFAULT_SUGGESTED))


parser_topics = subparsers.add_parser('topics', help='generate topics using LDA')
parser_topics.set_defaults(hook=topics)
parser_topics.add_argument('features', help='dataset to use')
parser_topics.add_argument('-n', '--ntopics', type=int, default=DEFAULT_NTOPICS, \
                            help='number of topics to generate (default: {})'.format(DEFAULT_NTOPICS))
parser_topics.add_argument('-p', '--pertopic', type=int, default=DEFAULT_PERTOPIC, \
                           help='number of words to print per topic (default: {})'.format(DEFAULT_PERTOPIC))


parser_dev = subparsers.add_parser('dev', help='for developers only')
parser_dev.set_defaults(hook=dev)
parser_dev.add_argument('features')






args = parser.parse_args()
if args.cmd:
    args.hook(args)
