import numpy as np

from classifier import *


def ranks_dict(l):
    D = {}
    for i in range(len(l)):
        D[l[i]] = i
    return D

class Merge:

    def __init__(self, C1, C2, r=0.3):
        self.C1 = C1
        self.C2 = C2
        self.r = r


    def best_lemmas(self, fs, numfs={}, n=-1):

        C1l = list(self.C1.best_lemmas(fs, numfs=numfs, n=n))
        C2l = list(self.C2.best_lemmas(fs, numfs=numfs, n=n))

        Cl = list(set(C1l) | set(C2l))

        R1 = ranks_dict(C1l)
        R2 = ranks_dict(C2l)

        def rank(l):
            return (1 - self.r) * R1.get(l, n + 1) + self.r * R2.get(l, n + 1)

        return list(sorted(Cl, key=rank))[:n]
        

    def known_deps(self):
        return list(set(self.C1.known_deps()))
        
