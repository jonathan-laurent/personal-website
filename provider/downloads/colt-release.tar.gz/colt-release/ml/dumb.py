import random
import training_set


class Random:

    def __init__(self, T):
        self.catdeps = T.catdeps
        
    def best_lemmas(self, fs, numfs={}, n=-1):
        b = self.catdeps[:]
        random.shuffle(b)
        return b[:n]

    def known_deps(self):
        return self.catdeps


class MostFrequent:

    def __init__(self, T):
        self.sorted_deps = [d for d, c in training_set.deps_usage(T)]
        
    def best_lemmas(self, fs, numfs={}, n=-1):
        return self.sorted_deps[:n]

    def known_deps(self):
        return self.sorted_deps
