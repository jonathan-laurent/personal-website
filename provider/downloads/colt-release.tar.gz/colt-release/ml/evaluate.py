import training_set
import naive_bayes as nb

import numpy as np

def cover_curve(C, T, I=(100, 100)):

    linf=I[0]-1
    lsup=I[1]

    covs = []

    known_deps = set(C.known_deps())

    for k, ds in T.deps.items():
        set_ds = set(ds) & known_deps
        if len(set_ds) >= 4:
            fs = T.feats[k]
            numfs = T.numfeats[k]
            best = C.best_lemmas(fs, numfs=numfs, n=lsup)

            tab = np.zeros(lsup-linf)
            b1 = best[:linf]
            b2 = best[linf:]

            q = len(set(b1) & set_ds)
            for i in range(len(tab)):
                if b2[i] in set_ds:
                    q += 1
                tab[i] = q

            tab /= len(set_ds)
            covs.append(tab)

    return np.mean(np.array(covs), axis=0)


def cover(C, T, n=100):
    return cover_curve(C, T, (n, n))[0]
    

def compare_estimators(Cs, T_test, I):
    
    legends = [l for C, l in Cs]
    ests    = [C for C, l in Cs] 


    import matplotlib.pyplot as plt
    from matplotlib import rc
    rc('text', usetex=True)
    rc('font', **{'family':'serif', 'serif':['Computer Modern Roman'], 
                  'monospace': ['Computer Modern Typewriter']})

    h=7
    plt.figure("Cover curve", (1.2*h, h))
    
    #plt.title("Cover curve")
    plt.xlabel("Number of suggestions")
    plt.ylabel("Cover rate")

    xx  = range(I[0], I[1] + 1)

    for C in ests:
        yy = cover_curve(C, T_test, I)
        plt.plot(xx, yy)
        
    plt.ylim([0, 1])
    plt.legend(legends, loc='upper left', fontsize=12)
    plt.show()
