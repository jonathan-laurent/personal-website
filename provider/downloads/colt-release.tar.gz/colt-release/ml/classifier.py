import pickle


def feats_list_to_dict(l):
    d = {}
    for x in l:
        d[x] = 1
    return d


class Base:

    def __init__(self, train_from=None, from_file=""):
        if from_file != "":
            self.load(from_file)
        if train_from:
            self.fit(train_from)

    def fit(self, T):
        pass
    
    def save(self, filename):
        pickle.dump(self.get_state(), open(filename, "wb"))

    def load(self, filename):
        st = pickle.load(open(filename, "rb"))
        self.set_state(st)
